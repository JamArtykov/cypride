<?php
// Start session and connect to the database
session_start();
include('connection.php');

// Retrieve all trips for the user
$sql = "SELECT * FROM carsharetrips WHERE user_id = '" . $_SESSION['user_id'] . "'";

if ($result = mysqli_query($link, $sql)) {
    if (mysqli_num_rows($result) > 0) {
        $activeTrips = array(); // Array to store active trips
        $passedTrips = array(); // Array to store passed trips
        $joinedTrips = array(); // Array to store joined trips

        $currentDateTime = date('Y-m-d H:i:s');
        $currentDateTimeTimestamp = strtotime($currentDateTime);
        
        while ($row = mysqli_fetch_array($result)) {
            $tripDate = date('Y-m-d', strtotime($row['date']));
            $tripTime = date('H:i:s', strtotime($row['time']));
            $tripDateTime = $tripDate . ' ' . $tripTime;
            $tripDateTimeTimestamp = strtotime($tripDateTime);
        
            
            if ($tripDateTimeTimestamp >= $currentDateTimeTimestamp) {
                $activeTrips[] = $row;
            } else {
                $passedTrips[] = $row;
            }
             
        }

        // Sort the active trips by date and time
        usort($activeTrips, function($a, $b) {
            return strtotime($a['date'] . ' ' . $a['time']) - strtotime($b['date'] . ' ' . $b['time']);
        });

        // Sort the passed trips by date and time in descending order
        usort($passedTrips, function($a, $b) {
            return strtotime($b['date'] . ' ' . $b['time']) - strtotime($a['date'] . ' ' . $a['time']);
        });

        // Retrieve joined trips
        $joinedTripsQuery = "SELECT carsharetrips.* FROM carsharetrips JOIN trip_participants ON carsharetrips.trip_id = trip_participants.trip_id WHERE trip_participants.user_id = '" . $_SESSION['user_id'] . "' AND trip_participants.is_driver = 0";

        if ($joinedTripsResult = mysqli_query($link, $joinedTripsQuery)) {
            while ($row = mysqli_fetch_array($joinedTripsResult)) {
                $joinedTrips[] = $row;
            }
        }

        // Sort the joined trips by date and time
        usort($joinedTrips, function($a, $b) {
            return strtotime($a['date'] . ' ' . $a['time']) - strtotime($b['date'] . ' ' . $b['time']);
        });

        // Render the sorted trips
        renderTrips($activeTrips, 'Active Trips');
        renderTrips($joinedTrips, 'Joined Trips');
        renderTrips($passedTrips, 'Passed Trips');
    } else {
        echo '<div class="notrips alert alert-warning">You have not created any trips yet</div>';
    }
}

function renderTrips($trips, $title) {
    echo '<h2>' . $title . '</h2>';

    foreach ($trips as $trip) {
        $departure = $trip['departure'];
        $destination = $trip['destination'];
        $date = $trip['date'];
        $time = $trip['time'];
        $regular = $trip['regular'];
        $price = $trip['price'];
        $seatsavailable = $trip['seatsavailable'];
        $trip_id = $trip['trip_id'];

        echo '
        <div class="row trip">
            <div class="col-sm-8 journey">
                <div><span class="departure">Departure:</span> ' . $departure . '.</div>
                <div><span class="destination">Destination:</span> ' . $destination . '.</div>
                <div class="time">' . $date . ' at ' . $time . '.</div>
                
            </div>
            <div class="col-sm-2 price">
                <div class="price">' . $price . '</div>
                <div class="perseat">Per Seat</div>
                <div class="seatsavailable">' . $seatsavailable . ' left</div>
            </div>
            <div class="col-sm-2">';

        // Display Edit button for active and passed trips
        if ($title !== 'Joined Trips') {
            echo '
                <button class="btn green edit btn-lg" data-target="#edittripModal" data-toggle="modal" data-trip_id="' . $trip_id . '">Edit</button>';
        }

        // Display View button for all trips
        echo '
                <a href="viewtrip.php?trip_id=' . $trip_id . '" class="btn green btn-lg active" style="color: black; margin-top: 10px;" aria-pressed="true">View</a>
            </div>
        </div>';
    }
}
?>
