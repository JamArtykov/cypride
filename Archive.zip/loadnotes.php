<?php
session_start();
include('connection.php');

$chatId = $_GET['trip_id'];

$sql = "SELECT chat_id FROM chats WHERE chat_id = $chatId";
$result = mysqli_query($link, $sql);

$sqlMessages = "SELECT m.message_id, m.message, m.timestamp, u.profilepicture, CONCAT(u.first_name, ' ', u.last_name) AS full_name
                FROM chat_messages m
                INNER JOIN users u ON m.user_id = u.user_id
                WHERE m.chat_id = $chatId
                ORDER BY m.timestamp ASC";

$resultMessages = mysqli_query($link, $sqlMessages);

$messages = array();

while ($row = mysqli_fetch_assoc($resultMessages)) {
    $message = array(
        'message_id' => $row['message_id'],
        'message' => $row['message'],
        'timestamp' => $row['timestamp'],
        'profilepicture' => $row['profilepicture'],
        'full_name' => $row['full_name'],
        'initial_profilepicture' => $row['profilepicture'],
        'initial_full_name' => $row['full_name']
    );
    $messages[] = $message;
}

?>  

<!DOCTYPE html>
<html>
<head>
    <title>Chat Window</title>
    <link href='https://fonts.googleapis.com/css?family=Arvo' rel='stylesheet' type='text/css'>
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
      <link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/sunny/jquery-ui.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-alpha1/dist/css/bootstrap.min.css"></link>
    <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-alpha1/dist/css/bootstrap.min.css"></link>
    <style>
body{
  background:#651fff;
}

::-webkit-scrollbar {
    width: 10px
}

::-webkit-scrollbar-track {
    background: #eee
}

::-webkit-scrollbar-thumb {
    background: #888
}

::-webkit-scrollbar-thumb:hover {
    background: #555
}

.wrapper {
    height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
    background-color: #651FFF
}

.main {
    background-color: #eee;
    width: 320px;
    position: relative;
    border-radius: 8px;
    box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
    padding: 6px 0px 0px 0px
}

.scroll {
    overflow-y: scroll;
    scroll-behavior: smooth;
    height: 325px
}

.img1 {
    border-radius: 50%;
    background-color: #66BB6A
}

.name {
    font-size: 8px
}

.msg {
    background-color: #fff;
    font-size: 11px;
    padding: 5px;
    border-radius: 5px;
    font-weight: 500;
    color: #3e3c3c
}

.between {
    font-size: 8px;
    font-weight: 500;
    color: #a09e9e
}

.navbar {
    border-bottom-left-radius: 8px;
    border-bottom-right-radius: 8px;
    box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19)
}

.form-control {
    font-size: 12px;
    font-weight: 400;
    width: 230px;
    height: 30px;
    border: none
}

form-control: focus {
    box-shadow: none;
    overflow: hidden;
    border: none
}

.form-control:focus {
    box-shadow: none !important
}

.icon1 {
    color: #7C4DFF !important;
    font-size: 18px !important;
    cursor: pointer
}

.icon2 {
    color: #512DA8 !important;
    font-size: 18px !important;
    position: relative;
    left: 8px;
    padding: 0px;
    cursor: pointer
}

.icondiv {
    border-radius: 50%;
    width: 15px;
    height: 15px;
    padding: 2px;
    position: relative;
    bottom: 1px
}
    </style>

</head>
<body>
<div class="d-flex justify-content-center container mt-5">
    <div class="wrapper">
        <div class="main">
            <div id="chat-messages" class="px-2 scroll">
                <?php foreach ($messages as $message) : ?>
                    <div class="d-flex align-items-center">
                        <div class="text-left pr-1">
                            <img src="<?php echo $message['profilepicture']; ?>" width="30" class="img1">
                        </div>
                        <div class="pr-2 pl-1">
                            <span class="name"><?php echo $message['full_name']; ?></span>
                            <p class="msg"><?php echo $message['message']; ?></p>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
            <nav class="navbar bg-white navbar-expand-sm d-flex justify-content-between">
                <input type="text" id="message-input" class="form-control" placeholder="Type a message...">
                <button id="send-button" class="btn btn-primary">Send</button>
            </nav>
        </div>
    </div>
</div>

<script>
    // JavaScript to handle sending and loading messages
    $(document).ready(function () {
        var messages = <?php echo json_encode($messages); ?>;
        var chatMessages = $('#chat-messages');
        var chatId = <?php echo $chatId; ?>;

        // Function to fetch and display messages
        function loadMessages() {
            // Clear existing messages
            chatMessages.empty();

            // Append new messages to the chat window
            $.each(messages, function (index, message) {
                var messageElement = $('<div class="d-flex align-items-center">' +
                    '<div class="text-left pr-1">' +
                    '<img src="' + message.profilepicture + '" width="30" class="img1">' +
                    '</div>' +
                    '<div class="pr-2 pl-1">' +
                    '<span class="name">' + message.full_name + '</span>' +
                    '<p class="msg">' + message.message + '</p>' +
                    '</div>' +
                    '</div>');

                chatMessages.append(messageElement);
            });

            // Scroll to the bottom of the chat window
            chatMessages.scrollTop(chatMessages.prop('scrollHeight'));
            console.log("Loaded messages");
        }

        // Load messages on page load
        loadMessages();

        // Function to send a new message
        function sendMessage() {
            var messageInput = $('#message-input');
            var message = messageInput.val().trim();

            // Perform validation
            if (message === '') {
                alert('Please enter a message.');
                return;
            }

            // Perform AJAX request to send the message
            $.ajax({
                url: 'createmessages.php',
                type: 'POST',
                data: { chat_id: chatId, message: message },
                success: function (response) {
                    // Clear the message input
                    messageInput.val('');
                    console.log("created message");
                    // Reload messages after sending
                    loadMessages();
                }
            });
        }

        // Send button click event listener
        $('#send-button').click(function () {
            sendMessage();
        });

        // Enter key press event listener for sending messages
        $('#message-input').keypress(function (e) {
            if (e.which === 13) {
                sendMessage();
                return false;
            }
        });
    });
</script>
</body>
</html>


